# Featured Categories

A Discourse theme component. Feature categories on select views.
